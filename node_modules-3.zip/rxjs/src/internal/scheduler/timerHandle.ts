export type TimerHandle = number | NodeJS.Timeout;
