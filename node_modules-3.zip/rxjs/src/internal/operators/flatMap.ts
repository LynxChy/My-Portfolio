import { mergeMap } from './mergeMap';

/**
 * @deprecated Renamed to {@link mergeMap}. Will be removed in v8.
 */
export const flatMap = mergeMap;
