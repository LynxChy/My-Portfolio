export declare type Easing = (v: number) => number;
export declare type EasingModifier = (easing: Easing) => Easing;
