export declare function cubicBezier(mX1: number, mY1: number, mX2: number, mY2: number): import("./types").Easing;
