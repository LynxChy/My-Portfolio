export declare function velocityPerFrame(xps: number, frameDuration: number): number;
