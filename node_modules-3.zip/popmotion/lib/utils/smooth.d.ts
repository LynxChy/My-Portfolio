export declare const smooth: (strength?: number) => (v: number) => number;
