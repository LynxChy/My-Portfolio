export declare const toDecimal: (num: number, precision?: number) => number;
