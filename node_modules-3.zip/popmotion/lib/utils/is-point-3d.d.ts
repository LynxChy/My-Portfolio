import { Point, Point3D } from '../types';
export declare const isPoint3D: (point: Point) => point is Point3D;
