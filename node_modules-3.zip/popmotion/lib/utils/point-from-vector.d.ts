import { Point2D } from '../types';
export declare const pointFromVector: (origin: Point2D, angle: number, distance: number) => {
    x: number;
    y: number;
};
