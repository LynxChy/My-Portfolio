export declare const mix: (from: number, to: number, progress: number) => number;
