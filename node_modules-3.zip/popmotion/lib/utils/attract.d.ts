export declare const createAttractor: (alterDisplacement?: Function) => (constant: number, origin: number, v: number) => number;
export declare const attract: (constant: number, origin: number, v: number) => number;
export declare const attractExpo: (constant: number, origin: number, v: number) => number;
