export declare const pipe: (...transformers: Function[]) => Function;
