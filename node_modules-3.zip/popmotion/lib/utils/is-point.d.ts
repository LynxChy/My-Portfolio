import { Point } from '../types';
export declare const isPoint: (point: Object) => point is Point;
