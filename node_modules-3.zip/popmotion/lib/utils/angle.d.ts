import { Point } from '../types';
export declare const angle: (a: Point, b?: Point) => number;
