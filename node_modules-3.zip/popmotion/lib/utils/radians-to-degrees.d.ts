export declare const radiansToDegrees: (radians: number) => number;
