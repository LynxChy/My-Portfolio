export declare const applyOffset: (from: number, to?: number) => (v: number) => number;
