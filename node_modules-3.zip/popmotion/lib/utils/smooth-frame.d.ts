export declare const smoothFrame: (prevValue: number, nextValue: number, duration: number, smoothing?: number) => number;
