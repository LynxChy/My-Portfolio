export declare const clamp: (min: number, max: number, v: number) => number;
