export declare function velocityPerSecond(velocity: number, frameDuration: number): number;
