import { HSLA, RGBA } from "style-value-types";
export declare function hslaToRgba({ hue, saturation, lightness, alpha }: HSLA): RGBA;
