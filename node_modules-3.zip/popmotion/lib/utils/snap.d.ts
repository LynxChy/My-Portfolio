export declare const snap: (points: number | number[]) => (v: number) => number;
