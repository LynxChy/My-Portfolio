export declare const degreesToRadians: (degrees: number) => number;
