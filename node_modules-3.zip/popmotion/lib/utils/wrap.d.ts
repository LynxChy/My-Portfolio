export declare const wrap: (min: number, max: number, v: number) => number;
