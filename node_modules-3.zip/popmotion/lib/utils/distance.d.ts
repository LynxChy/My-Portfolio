import { Point } from "../types";
export declare function distance<P extends Point | number>(a: P, b: P): number;
