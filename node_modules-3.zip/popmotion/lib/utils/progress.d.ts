export declare const progress: (from: number, to: number, value: number) => number;
