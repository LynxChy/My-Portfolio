import { Animation } from "../../types";
export declare function animateSync(animation: Animation<number>, timeStep?: number, round?: boolean): number[];
