export declare function loopElapsed(elapsed: number, duration: number, delay?: number): number;
export declare function reverseElapsed(elapsed: number, duration: number, delay?: number, isForwardPlayback?: boolean): number;
export declare function hasRepeatDelayElapsed(elapsed: number, duration: number, delay: number, isForwardPlayback: boolean): boolean;
