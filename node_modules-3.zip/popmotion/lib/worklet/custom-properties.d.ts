export declare function namespace(name: string): string;
export declare function registerCustomProperties(): void;
