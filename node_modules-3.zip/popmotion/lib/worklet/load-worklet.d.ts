export declare function whenWorkletReady(): Promise<void>;
export declare function workletReady(): void;
