import { TAllClassnames } from '../types/classes';
import { TailwindConfigParser } from './TailwindConfigParser';
export declare class FileContentGenerator {
    private _configParser;
    private readonly _generatedClassNames;
    /**
     * Initializes a new instance of the `FileContentGenerator` class.
     * @param generatedClassnames The generated classnames to put in the template.
     */
    constructor(generatedClassnames: TAllClassnames, configParser: TailwindConfigParser);
    generateFileContent: () => string;
    private fileHeaderTemplate;
    private importStatementsTemplate;
    private variantsTypeTemplate;
    private regularClassnamesTypesTemplate;
    private utilityFunctionsTemplate;
    private mainExportStatementsTemplate;
    /**
     * Generates types group template for a utility classes group object.
     *
     *
     * ### example:
     *
     * A utility group object as:
     *
     * ```js
     * const FlexBox = {
     *   alignSelf: ['self-auto', 'self-start', 'self-center'],
     *   flexWrap: ['flex-nowrap', 'flex-wrap'],
     * }
     *```
     *
     * will produce a template which looks like this:
     *
     * ```ts
     * export type TFlexWrap =
     * | 'flex-nowrap'
     * | 'flex-wrap';
     *
     * export type TAlignSelf =
     * | 'self-auto'
     * | 'self-start'
     * | 'self-center';
     *
     * export type TFlexBox = TFlexWrap | TAlignSelf;
     * ```
     */
    private generateTypesGroupTemplate;
    /**
     * Generates TS types template from a list of strings.
     *
     * #### Example:
     *
     * Given typeName: 'baz' and items:
     * ```js
     * ['foo', 'bar']
     * ```
     *
     * generates:
     *
     * ```
     * export type TBaz
     *   | foo
     *   | bar;
     * ```
     * or with quoutes:
     * ```
     * export type TBaz
     *   | 'foo'
     *   | 'bar';
     * ```
     * @param typeName The name of the type (without T prefix).
     * @param items The list of the strings of items to add to the type name.
     * @param prefix The prefix to add to the beginning of each item of the string array.
     * @param surroundWithQuotes Whether to quote the types or not (make it a string or an actual type)
     */
    private generateTypesTemplate;
}
