export declare const baseVariants: string[];
