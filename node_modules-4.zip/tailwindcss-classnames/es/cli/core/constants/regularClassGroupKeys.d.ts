export declare const regularClassGroupKeys: string[];
