import { TailwindConfigParser } from './TailwindConfigParser';
import { TAllClassnames } from '../types/classes';
/**
 * Responsible for generating the types from a parsed config by ConfigScanner.
 */
export declare class ClassnamesGenerator {
    private readonly _prefix;
    private readonly _separator;
    private readonly _darkMode;
    private readonly _theme;
    private readonly _configParser;
    private readonly _generatedRegularClassnames;
    private readonly _generatedPseudoClassnames;
    /**
     * Initializes a new instance of the `ClassesGenerator` class.
     * @param tailwindConfig The _parsed_ TailwindCSS Config.
     */
    constructor(parser: TailwindConfigParser);
    /**
     * Get the generated classnames.
     */
    generate: () => TAllClassnames;
    private layout;
    private backgrounds;
    private borders;
    private tables;
    private effects;
    private transitionsAndAnimations;
    private transforms;
    private interactivity;
    private SVG;
    private accessibility;
    private filters;
    private flexBox;
    private grid;
    private spacing;
    private sizing;
    private typography;
    private pseudoClasses;
    private generateClassesWithColors;
    private getGeneratedClassesWithOpacities;
}
