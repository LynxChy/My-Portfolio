import { TTailwindCSSConfig, TConfigDarkMode, TConfigPlugins } from '../types/config';
import { TThemeItems } from '../types/config';
/**
 * Parses the tailwind config object
 */
export declare class TailwindConfigParser {
    private readonly _mode;
    private readonly _prefix;
    private readonly _separator;
    private readonly _darkMode;
    private readonly _themeConfig;
    private _evaluatedTheme;
    private readonly _pluginsConfig;
    constructor(tailwindConfig: TTailwindCSSConfig, plugins: TConfigPlugins);
    /**
     *  Gets the config prefix value
     */
    getPrefix: () => string;
    /**
     *  Gets the config dark mode value
     */
    getDarkMode: () => TConfigDarkMode;
    /**
     * Gets the config separator value
     */
    getSeparator: () => string;
    /**
     * Gets the config plugins value
     */
    getPlugins: () => TConfigPlugins | null;
    /**
     *  Gets the config theme object
     */
    getTheme: () => TThemeItems;
    /**
     * Get the pseudoclass variants based on config.
     */
    getVariants: () => string[];
    /**
     * Get the value (and key) of a supplied theme property.
     * @param themeProperty The theme property name
     */
    getThemeProperty: (themeProperty: keyof TThemeItems) => [string[], Array<string | Record<string, string>>];
}
