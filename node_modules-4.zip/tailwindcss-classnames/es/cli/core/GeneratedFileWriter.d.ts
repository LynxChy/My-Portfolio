declare type TCliOptions = {
    configFilename: string | void;
    outputFilename: string | void;
    customClassesFilename: string | void;
};
/**
 * Responsible for writing a file with the generated content to the disk.
 */
export declare class GeneratedFileWriter {
    private readonly _configFilename;
    private readonly _outputFilename;
    private readonly _customClassesFilename;
    /** The data returned from reading the config file */
    private _configFileData;
    /**
     * Initializes a new instance of `GeneratedFileWriter` class.
     * @param options The parsed CLI options from user input.
     */
    constructor(options: TCliOptions);
    /**
     * Writes the generated file to disk.
     */
    write: () => Promise<void>;
    private evaluateTailwindConfigFile;
    private generateFileContent;
    private validateCliOptions;
    private printCliMessage;
}
export {};
