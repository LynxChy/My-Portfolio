declare const _default: {
    hardwareAcceleration: string[];
};
export default _default;
