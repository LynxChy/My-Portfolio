declare const _default: {
    filter: string[];
    backdropFilter: string[];
};
export default _default;
