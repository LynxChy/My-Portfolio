declare const _default: {
    flexDirection: string[];
    flexWrap: string[];
    alignItems: string[];
    alignContent: string[];
    alignSelf: string[];
    placeContent: string[];
    placeItems: string[];
    placeSelf: string[];
    justifyContent: string[];
    justifyItems: string[];
    justifySelf: string[];
    flex: string[];
};
export default _default;
