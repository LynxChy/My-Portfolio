declare const _default: {
    fontSmoothing: string[];
    fontStyle: string[];
    fontVariantNumeric: string[];
    listStylePosition: string[];
    textAlign: string[];
    textDecoration: string[];
    textTransform: string[];
    textOverflow: string[];
    verticalAlign: string[];
    whitespace: string[];
    wordBreak: string[];
    textDecorationStyle: string[];
};
export default _default;
