declare const _default: {
    display: string[];
    boxDecorationBreak: string[];
    boxSizing: string[];
    container: string[];
    float: string[];
    clear: string[];
    isolation: string[];
    objectFit: string[];
    overflow: string[];
    overscrollBehavior: string[];
    position: string[];
    visibility: string[];
    breakBefore: string[];
    breakInside: string[];
    breakAfter: string[];
};
export default _default;
