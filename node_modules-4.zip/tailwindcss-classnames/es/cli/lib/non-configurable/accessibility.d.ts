declare const _default: {
    screenReaders: string[];
};
export default _default;
