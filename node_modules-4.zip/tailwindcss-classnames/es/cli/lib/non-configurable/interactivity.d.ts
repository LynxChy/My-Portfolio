declare const _default: {
    appearance: string[];
    pointerEvents: string[];
    resize: string[];
    userSelect: string[];
    scrollSnap: string[];
    scrollBehavior: string[];
    touchAction: string[];
};
export default _default;
