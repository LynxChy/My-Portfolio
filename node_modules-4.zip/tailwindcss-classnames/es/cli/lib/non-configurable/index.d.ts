export declare const nonConfigurableClassNames: {
    accessibility: {
        screenReaders: string[];
    };
    backgrounds: {
        backgroundAttachment: string[];
        backgroundClip: string[];
        backgroundOrigin: string[];
        backgroundRepeat: string[];
    };
    borders: {
        borderStyle: string[];
        divideStyle: string[];
        outlineStyle: string[];
    };
    effects: {
        mixBlendMode: string[];
        backgroundBlendMode: string[];
    };
    filters: {
        filter: string[];
        backdropFilter: string[];
    };
    flexBox: {
        flexDirection: string[];
        flexWrap: string[];
        alignItems: string[];
        alignContent: string[];
        alignSelf: string[];
        placeContent: string[];
        placeItems: string[];
        placeSelf: string[];
        justifyContent: string[];
        justifyItems: string[];
        justifySelf: string[];
        flex: string[];
    };
    grid: {
        gridAutoFlow: string[];
    };
    interactivity: {
        appearance: string[];
        pointerEvents: string[];
        resize: string[];
        userSelect: string[];
        scrollSnap: string[];
        scrollBehavior: string[];
        touchAction: string[];
    };
    layout: {
        display: string[];
        boxDecorationBreak: string[];
        boxSizing: string[];
        container: string[];
        float: string[];
        clear: string[];
        isolation: string[];
        objectFit: string[];
        overflow: string[];
        overscrollBehavior: string[];
        position: string[];
        visibility: string[];
        breakBefore: string[];
        breakInside: string[];
        breakAfter: string[];
    };
    sizing: {};
    spacing: {};
    svg: {};
    tables: {
        borderCollapse: string[];
        tableLayout: string[];
    };
    transforms: {
        hardwareAcceleration: string[];
    };
    transitionsAndAnimations: {};
    typography: {
        fontSmoothing: string[];
        fontStyle: string[];
        fontVariantNumeric: string[];
        listStylePosition: string[];
        textAlign: string[];
        textDecoration: string[];
        textTransform: string[];
        textOverflow: string[];
        verticalAlign: string[];
        whitespace: string[];
        wordBreak: string[];
        textDecorationStyle: string[];
    };
};
