declare const _default: {
    borderStyle: string[];
    divideStyle: string[];
    outlineStyle: string[];
};
export default _default;
