declare const _default: {
    gridAutoFlow: string[];
};
export default _default;
