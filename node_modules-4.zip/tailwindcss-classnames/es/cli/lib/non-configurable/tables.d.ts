declare const _default: {
    borderCollapse: string[];
    tableLayout: string[];
};
export default _default;
