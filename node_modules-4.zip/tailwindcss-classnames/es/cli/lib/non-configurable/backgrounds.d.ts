declare const _default: {
    backgroundAttachment: string[];
    backgroundClip: string[];
    backgroundOrigin: string[];
    backgroundRepeat: string[];
};
export default _default;
