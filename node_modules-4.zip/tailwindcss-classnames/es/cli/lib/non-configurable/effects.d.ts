declare const _default: {
    mixBlendMode: string[];
    backgroundBlendMode: string[];
};
export default _default;
