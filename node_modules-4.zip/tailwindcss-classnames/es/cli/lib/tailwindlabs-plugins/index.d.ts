export declare const tailwindLabsPlugins: {
    pluginTypography: string[];
    pluginCustomForms: string[];
};
