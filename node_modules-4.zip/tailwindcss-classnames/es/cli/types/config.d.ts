import { baseVariants } from '../core/constants/baseVariants';
import { defaultTailwindConfig } from '../lib/defaultTailwindConfig';
export declare type TTailwindCSSConfig = Partial<typeof defaultTailwindConfig & Record<'separator' | 'prefix' | 'mode', string>>;
export declare type TConfigDarkMode = false | 'media' | 'class';
export declare type TConfigTheme = TThemeItems & {
    extend?: TThemeItems;
};
export declare type TConfigVariants = TVariantsItems & {
    extend?: Partial<TVariantsItems>;
};
export declare type TConfigPlugins = Partial<Record<'pluginTypography' | 'pluginCustomForms', boolean>>;
export declare type TThemeItems = typeof defaultTailwindConfig.theme;
declare type TVariantsItems = typeof baseVariants;
export {};
