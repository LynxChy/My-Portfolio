import { ValueType } from '../types';
export declare const number: ValueType;
export declare const alpha: ValueType;
export declare const scale: ValueType;
