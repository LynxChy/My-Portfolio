import { ValueType } from '../types';
export declare const degrees: ValueType;
export declare const percent: ValueType;
export declare const px: ValueType;
export declare const vh: ValueType;
export declare const vw: ValueType;
export declare const progressPercentage: ValueType;
