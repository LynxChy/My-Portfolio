import { ValueType } from '../types';
export declare const hex: ValueType;
