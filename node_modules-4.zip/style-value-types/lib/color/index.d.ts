import { ValueType } from '../types';
export declare const color: ValueType;
