import { ValueType } from '../types';
export declare const hsla: ValueType;
