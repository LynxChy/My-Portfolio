import { ValueType } from '../types';
export declare const rgbUnit: ValueType;
export declare const rgba: ValueType;
